#include <iostream>
#include <bits/stdc++.h>
using namespace std;
bool matchingParenthesis(string s)
{
    stack<char> st;
    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == '(' || s[i] == '{' || s[i] == '[')
        {
            st.push(s[i]);
        }
        else
        {
            if (st.empty() ||
                (s[i] == ')' && st.top() != '(') ||
                (s[i] == '}' && st.top() != '{') ||
                (s[i] ==  ']' && st.top() != '['))
            {
                return false;
            }
            st.pop();
        }
    }
    return st.empty();
}

int priority(char c)
{
    if (c == '+' || c == '-')
        return 1;
    if (c == '*' || c == '/')
        return 2;
    if (c == '^')
        return 3;
    return -1;
}

string infixToPostfix(string s)
{
    stack<char> stack;
    string ans;
    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] >= 'A' && s[i] <= 'Z' ||
            s[i] >= 'a' && s[i] <= 'z' ||
            s[i] >= '0' && s[i] <= '9')
        {
            ans += s[i];
        }
        else if (s[i] == '(')
        {
            stack.push(s[i]);
        }
        else if (s[i] == ')')
        {
            while (!stack.empty() && stack.top() != '(')
            {
                ans += stack.top();
                stack.pop();
            }
            stack.pop();
        }
        else
        {
            while (!stack.empty() && priority(s[i]) <= priority(stack.top()))
            {
                ans += stack.top();
                stack.pop();
            }
            stack.push(s[i]);
        }
    }
    while (!stack.empty())
    {
        ans += stack.top();
        stack.pop();
    }
    return ans;
}

int evaluatePostfix(string s)
{
    stack<int> st;
    for (int i = 0; i < s.length(); i++)
    {
        if (isdigit(s[i]))
        {
            st.push(s[i] - '0');
        }
        else
        {
            int val1 = st.top();
            st.pop();
            int val2 = st.top();
            st.pop();

            if (s[i] == '+')
                st.push(val2 + val1);
            if (s[i] == '-')
                st.push(val2 - val1);
            if (s[i] == '*')
                st.push(val2 * val1);
            if (s[i] == '/')
                st.push(val2 / val1);
        }
    }
    return st.top();
}

int main()
{
    int choise;
    do
    {
        cout << "Enter a Choise: " << endl;
        cout << "1. Matching Paranthesis" << endl;
        cout << "2. Conversion of Infix to Postfix" << endl;
        cout << "3. Evaluation of Postfix" << endl;
        cout << "4. Exit" << endl;
        cin >> choise;
        switch (choise)
        {
        case 1:
        {
            string s;
            cout << "Enter the string" << endl;
            cin >> s;
            if (matchingParenthesis(s))
                cout << "Parenthesis are balanced" << endl;
            else
                cout << "Parenthesis are not balanced" << endl;
            break;
        }
        case 2:
        {
            string s;
            cout << "Enter the string" << endl;
            cin >> s;
            cout << infixToPostfix(s) << endl;
            break;
        }
        case 3:
        {
            string s;
            cout << "Enter the string" << endl;
            cin >> s;
            cout << "postfix evaluation: " << evaluatePostfix(s) << endl;
            break;
        }
        default:
            break;
        }
    } while (choise != 4);

    return 0;
}