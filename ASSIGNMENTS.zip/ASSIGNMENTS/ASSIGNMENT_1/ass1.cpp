#include <iostream>
#include <bits/stdc++.h>
using namespace std;
void bubble_sort(int arr[], int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    for (int i = 0; i < n; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}
 
int partition(int arr[], int low, int high)
{
    int pivot = arr[high];
    int i = (low - 1);
    for (int j = low; j < high; j++)
    {
        if (arr[j] <= pivot)
        {
            i++;
            int temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;
        }
    }
    int temp = arr[i + 1];
    arr[i + 1] = arr[high];
    arr[high] = temp;
    return (i + 1);
}
 
void quickSort(int arr[], int low, int high)
{
    if (low < high)
    {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}
 
int binary_search(int arr[], int n, int target)
{
    int low = 0;
    int high = n - 1;
    while (low <= high)
    {
        int mid = low + (high - low) / 2;
        if (arr[mid] == target)
        {
            return mid;
        }
        if (arr[mid] < target)
        {
            low = mid + 1;
        }
        if (arr[mid] > target)
        {
            high = mid - 1;
        }
    }
    return -1;
}
 
int main()
{
 
    int choise;
    do
    {
        cout << "1. Bubble Sort" << endl;
        cout << "2. Quick Sort" << endl;
        cout << "3. Binary Search" << endl;
        cout << "4. Exit" << endl;
        cin >> choise;
 
        switch (choise)
        {
        case 1:
            int n;
            {
                cout << "Enter the number of elements in array: ";
                cin >> n;
                int arr[n];
                cout << "Enter Elements\n";
                for (int i = 0; i < n; i++)
                {
                    cin >> arr[i];
                }
                bubble_sort(arr, n);
 
                break;
            }
        case 2:
            int t;
            {
                cout << "Enter the number of elements in array: ";
                cin >> t;
                int arr[t];
                cout << "Enter Elements\n";
                for (int i = 0; i < t; i++)
                {
                    cin >> arr[i];
                }
                quickSort(arr, 0, t - 1);
                for (int i = 0; i < t; i++)
                {
                    cout << arr[i] << " ";
                }
                cout << endl;
            }
            break;
        case 3:
        {
            cout << "Enter the number of elements in array: ";
            cin >> n;
            int arr[n];
            cout << "Enter Elements\n ";
            for (int i = 0; i < n; i++)
            {
                cin >> arr[i];
            }
            int target;
            cout << "Enter the Target Element: ";
            cin >> target;
            bubble_sort(arr, n);
 
            int index = binary_search(arr, n, target);
            if (index == -1)
            {
                cout << "Element Not Found" << endl;
            }
            else
            {
                cout << "Element Found at Index: " << index << endl;
            }
        }
        default:
            break;
        }
    } while (choise != 4);
 
    return 0;
}
