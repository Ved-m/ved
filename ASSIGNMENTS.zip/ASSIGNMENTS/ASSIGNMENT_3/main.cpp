#include <iostream>
#include <stack>
#include <queue>
using namespace std;

const int SIZE = 5;
int circularQueue[SIZE];
int front = -1, rear = -1;

void enqueue(int value) {
    if ((rear + 1) % SIZE == front) {
        cout << "Queue is full\n";
        return;
    }
    if (front == -1) { // Queue is empty
        front = 0;
    }
    rear = (rear + 1) % SIZE;
    circularQueue[rear] = value;
    cout << "Enqueued " << value << endl;
}

int dequeue() {
    if (front == -1) {
        cout << "Queue is empty\n";
        return -1;
    }
    int value = circularQueue[front];
    if (front == rear) { // Queue has only one element
        front = rear = -1;
    } else {
        front = (front + 1) % SIZE;
    }
    cout << "Dequeued " << value << endl;
    return value;
}

void displayQueue() {
    if (front == -1) {
        cout << "Queue is empty\n";
        return;
    }
    int i = front;
    cout << "Queue elements: ";
    while (i != rear) {
        cout << circularQueue[i] << " ";
        i = (i + 1) % SIZE;
    }
    cout << circularQueue[i] << endl;
}

// Function to reverse a stack using a queue
void reverseStack(stack<int>& s) {
    queue<int> q;
    while (!s.empty()) {
        q.push(s.top());
        s.pop();
    }
    while (!q.empty()) {
        s.push(q.front());
        q.pop();
    }
}

void printStack(stack<int> s) {
    while (!s.empty()) {
        cout << s.top() << " ";
        s.pop();
    }
    cout << endl;
}

int main() {
    int choice;
    do {
        cout << "Enter Your Choice:\n";
        cout << "1. Implementation of Circular Queue\n";
        cout << "2. Reversing Stack using Queue\n";
        cout << "3. Exit\n";
        cin >> choice;

        switch (choice) {
            case 1: {
                int newChoice;
                do {
                    cout << "\n--- Circular Queue Operations ---\n";
                    cout << "1. Enqueue Element\n";
                    cout << "2. Dequeue Element\n";
                    cout << "3. Display Queue\n";
                    cout << "4. Exit\n";
                    cout << "Enter your choice: ";
                    cin >> newChoice;

                    int value;
                    switch (newChoice) {
                        case 1:
                            cout << "Enter value to enqueue: ";
                            cin >> value;
                            enqueue(value);
                            break;
                        case 2:
                            dequeue();
                            break;
                        case 3:
                            displayQueue();
                            break;
                        case 4:
                            cout << "Exiting Circular Queue operations.\n";
                            break;
                        default:
                            cout << "Invalid choice! Please select again.\n";
                    }
                } while (newChoice != 4);
                break;
            }
            case 2: {
                stack<int> s;
                int stackChoice;
                do {
                    cout << "\n--- Stack Operations ---\n";
                    cout << "1. Push Element onto Stack\n";
                    cout << "2. Reverse Stack\n";
                    cout << "3. Display Stack\n";
                    cout << "4. Exit\n";
                    cout << "Enter your choice: ";
                    cin >> stackChoice;

                    switch (stackChoice) {
                        case 1: {
                            int value;
                            cout << "Enter value to push onto stack: ";
                            cin >> value;
                            s.push(value);
                            break;
                        }
                        case 2:
                            reverseStack(s);
                            cout << "Stack reversed.\n";
                            break;
                        case 3:
                            cout << "Stack elements: ";
                            printStack(s);
                            break;
                        case 4:
                            cout << "Exiting Stack operations.\n";
                            break;
                        default:
                            cout << "Invalid choice! Please select again.\n";
                    }
                } while (stackChoice != 4);
                break;
            }
            case 3:
                cout << "Exiting Program.\n";
                break;
            default:
                cout << "Invalid choice! Please select again.\n";
        }
    } while (choice != 3);

    return 0;
}

